import mysql.connector

db = mysql.connector.connect(
  host="localhost",
  user="root",
  password="",
  database="aplikasi"
)

cursor = db.cursor()
cursor.execute('select * from link')
result = cursor.fetchall()
for u in result:
    for i in u:
        if i == '###':
            print(i)