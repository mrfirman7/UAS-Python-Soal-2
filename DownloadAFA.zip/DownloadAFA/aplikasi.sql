-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 26, 2022 at 05:28 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aplikasi`
--

-- --------------------------------------------------------

--
-- Table structure for table `link`
--

CREATE TABLE `link` (
  `id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `nama` mediumtext NOT NULL,
  `direct` mediumtext DEFAULT NULL,
  `google` mediumtext DEFAULT NULL,
  `mediafire` mediumtext DEFAULT NULL,
  `zippyshare` mediumtext DEFAULT NULL,
  `password` mediumtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `link`
--

INSERT INTO `link` (`id`, `tanggal`, `nama`, `direct`, `google`, `mediafire`, `zippyshare`, `password`) VALUES
(27, '2021-12-27', 'Adobe Audition CC 2021 v22.1.1.23 Full Version', '', '', '', 'https://www80.zippyshare.com/v/sZOGJoK3/file.html', 'www.bagas31.info'),
(28, '2021-12-28', 'Stellar Data Recovery Technician 10.2.0.0 x64 Full Version', '', '', 'https://www.mediafire.com/file/a3spgxdglewbypr/%255Bgigapurbalingga.net%255D_StlrDtaRcTch10200x64.rar/file', '', ''),
(29, '2021-12-29', 'IDM Terbaru 6.40 Build 5 Final Full Crack', '', '', '', 'https://www112.zippyshare.com/v/JIhUVFQE/file.html', ''),
(30, '2021-12-30', 'Advanced System Protector 2.5.1111.29057 Full Crack', '', '', '', 'https://www90.zippyshare.com/v/wszT8B2i/file.html', ''),
(31, '2021-12-31', 'HyperSnap 8.21.00 Full Version', '', '', '', 'https://www90.zippyshare.com/v/HRkwdhxq/file.html', ''),
(32, '2022-01-01', 'Adobe Photoshop 2022 v23.0.0.36 x64 Final Activated', '', '', 'https://www.mediafire.com/file/msgybw3q0ic0xcm/%255Bgigapurbalingga.net%255D_AdbPht22v230036x64.rar/file', '', ''),
(33, '2022-01-02', 'Adobe Illustrator CC 2022 v26.0.0.730 Activated', '', '', 'https://www.mediafire.com/file/8tp46q05q8hcvba/%255Bgigapurbalingga.net%255D_Adbilst22v2600730x64.rar/file', '', ''),
(34, '2022-01-03', 'CorelDRAW Graphics Suite 2021.5 v23.5.0.506 Full Version', '', '', 'https://www.mediafire.com/file/0iu34kay7gsn3k0/CrlDrw21x64.rar/file', '', ''),
(35, '2022-01-04', 'Home Designer Professional 2022 v23.2.0.55 x64 Full Crack', '', '', '', 'https://www54.zippyshare.com/v/yaHNTPpR/file.html', ''),
(36, '2022-01-05', 'KMSAuto ++ 1.6.4', '', '', '', 'https://www23.zippyshare.com/v/viY9wwS5/file.html', ''),
(37, '2022-01-06', 'Malwarebytes Anti-Malware Premium 4.2.0.82 Full Crack', '', '', '', 'https://www83.zippyshare.com/v/eLJiZmdA/file.html', ''),
(38, '2022-01-07', 'SUPERAntiSpyware Pro X 10.0.1242 x64 Final Full Version', '', '', '', 'https://www37.zippyshare.com/v/qqUhAlJ1/file.html', ''),
(39, '2022-01-08', 'Sandboxie 5.55 Full Version', '', '', '', 'https://www31.zippyshare.com/v/J2tkioPs/file.html', 'www.bagas31.info'),
(40, '2022-01-09', 'Turbo VPN Pro APK 3.6.9', '', '', 'https://www.mediafire.com/file/m5n2jqo8fwifob0', '', 'www.bagas31.info'),
(41, '2022-01-10', 'Daemon Tools Lite 11.0.0.1920 Final', '', '', '', 'https://www39.zippyshare.com/v/HZjJjPia/file.html', ''),
(42, '2022-01-11', 'Bootstrap Studio 5.6.1 x64 Full Crack', '', '', '', 'https://www61.zippyshare.com/v/3azi92pn/file.html', ''),
(43, '2022-01-12', 'TeamViewer Windows', 'https://dl.teamviewer.com/download/version_15x/TeamViewer_Setup.exe?utm_source=google&utm_medium=cpc&utm_campaign=restofasia%7Cb%7Cpr%7C20%7Cjun%7Cexact-brand-only-sn%7Cfree%7Ct0%7C0&utm_content=exact_Brand-only&utm_term=teamviewer&gclid=EAIaIQobChMI_MXr0dvK9QIVLZFmAh1qMwrVEAAYASAAEgJIvfD_BwE&ref=https%3A%2F%2Fwww.teamviewer.com%2Fen%2Fdownload%2Fwindows%2F%3Futm_source%3Dgoogle%26utm_medium%3Dcpc%26utm_campaign%3Drestofasia%257Cb%257Cpr%257C20%257Cjun%257Cexact-brand-only-sn%257Cfree%257Ct0%257C0%26utm_content%3Dexact_Brand-only%26utm_term%3Dteamviewer%26gclid%3DEAIaIQobChMI_MXr0dvK9QIVLZFmAh1qMwrVEAAYASAAEgJIvfD_BwE', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `link`
--
ALTER TABLE `link`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `link`
--
ALTER TABLE `link`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
